
import asyncio
from redis.asyncio import Redis

EXAMPLE_DATA = [
    { "id": "tmdb_100", "title": "The Matrix", "type": "movie",
      "overview": "A hacker discovers the truth about reality.", "popularity": 95 },
    { "id": "tmdb_101", "title": "Breaking Bad", "type": "tv",
      "overview": "A chemistry teacher turns meth kingpin.", "popularity": 99 },
    { "id": "tmdb_102", "title": "Inception", "type": "movie",
      "overview": "Thieves invade dreams to steal secrets.", "popularity": 92 }
]

async def seed():
    r = Redis(host="localhost", port=6379, decode_responses=True)
    for item in EXAMPLE_DATA:
        item["search_title"] = item.get("title")
        key = f"media:{item['id']}"
        await r.json().set(key, "$", item)
        print("Seeded:", key)

if __name__ == "__main__":
    asyncio.run(seed())
