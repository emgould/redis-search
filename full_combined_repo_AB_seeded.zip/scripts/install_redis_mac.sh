
brew install redis
brew services start redis
