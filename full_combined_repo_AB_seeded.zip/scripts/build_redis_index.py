
import asyncio
from redis.asyncio import Redis

async def build_index():
    r = Redis(host="localhost", port=6379, decode_responses=True)

    try:
        await r.ft("idx:media").create_index(
            (
                ("$.search_title", "TEXT", {"WEIGHT": 5}),
                ("$.type", "TAG"),
            ),
            definition={"prefix": ["media:"]}
        )
        print("Index created successfully")
    except Exception as e:
        print("Index exists or failed:", e)

if __name__ == "__main__":
    asyncio.run(build_index())
