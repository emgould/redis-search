
# Full Combined Repo

Run local tools:
  make help
  make api
  make etl
  make web
  make test
