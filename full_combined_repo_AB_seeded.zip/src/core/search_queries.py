
def build_autocomplete_query(q: str):
    return f"@search_title:{q}*"

def build_fuzzy_fulltext_query(q: str):
    return f"(%{q}% | {q})"
