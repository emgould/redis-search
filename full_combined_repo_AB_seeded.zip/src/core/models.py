
from pydantic import BaseModel
from typing import Optional, Any

class MediaDocument(BaseModel):
    id: str
    type: Optional[str] = None
    search_title: Optional[str] = None
    original: dict[str, Any]
