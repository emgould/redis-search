
def derive_search_title(doc: dict):
    return (
        doc.get("title")
        or doc.get("name")
        or doc.get("headline")
        or doc.get("volumeInfo", {}).get("title")
    )
