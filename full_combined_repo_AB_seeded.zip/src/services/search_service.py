
from src.core.search_queries import (
    build_autocomplete_query,
    build_fuzzy_fulltext_query,
)
from src.adapters.redis_repository import RedisRepository

repo = RedisRepository()

async def autocomplete(q: str):
    query = build_autocomplete_query(q)
    res = await repo.search(query)
    return [doc.__dict__ for doc in res.docs]

async def full_search(q: str):
    query = build_fuzzy_fulltext_query(q)
    res = await repo.search(query)
    return [doc.__dict__ for doc in res.docs]
