
from .redis_client import get_redis

class RedisRepository:
    def __init__(self):
        self.redis = get_redis()
        self.idx = self.redis.ft("idx:media")

    async def search(self, query: str, limit: int = 10):
        return await self.idx.search(query, limit=limit)

    async def set_document(self, key: str, value: dict):
        await self.redis.json().set(key, "$", value)

    async def stats(self):
        info = await self.redis.info()
        dbsize = await self.redis.dbsize()
        return {"info": info, "dbsize": dbsize}
