
import os
from dotenv import load_dotenv

def load_env():
    env = os.getenv("ENV_FILE","config/dev.env")
    load_dotenv(env)
